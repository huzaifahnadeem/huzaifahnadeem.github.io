﻿namespace Calc_CS
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.key_1 = new System.Windows.Forms.Button();
            this.key_2 = new System.Windows.Forms.Button();
            this.key_3 = new System.Windows.Forms.Button();
            this.key_4 = new System.Windows.Forms.Button();
            this.key_5 = new System.Windows.Forms.Button();
            this.key_6 = new System.Windows.Forms.Button();
            this.key_7 = new System.Windows.Forms.Button();
            this.key_8 = new System.Windows.Forms.Button();
            this.key_9 = new System.Windows.Forms.Button();
            this.key_decimal = new System.Windows.Forms.Button();
            this.key_0 = new System.Windows.Forms.Button();
            this.key_equal = new System.Windows.Forms.Button();
            this.key_divide = new System.Windows.Forms.Button();
            this.key_multiply = new System.Windows.Forms.Button();
            this.key_minus = new System.Windows.Forms.Button();
            this.key_plus = new System.Windows.Forms.Button();
            this.key_C = new System.Windows.Forms.Button();
            this.key_CE = new System.Windows.Forms.Button();
            this.display_box = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // key_1
            // 
            this.key_1.Location = new System.Drawing.Point(63, 669);
            this.key_1.Name = "key_1";
            this.key_1.Size = new System.Drawing.Size(187, 104);
            this.key_1.TabIndex = 0;
            this.key_1.Text = "1";
            this.key_1.UseVisualStyleBackColor = true;
            this.key_1.Click += new System.EventHandler(this.key_1_Click);
            // 
            // key_2
            // 
            this.key_2.Location = new System.Drawing.Point(300, 669);
            this.key_2.Name = "key_2";
            this.key_2.Size = new System.Drawing.Size(187, 104);
            this.key_2.TabIndex = 0;
            this.key_2.Text = "2";
            this.key_2.UseVisualStyleBackColor = true;
            this.key_2.Click += new System.EventHandler(this.key_2_Click);
            // 
            // key_3
            // 
            this.key_3.Location = new System.Drawing.Point(539, 669);
            this.key_3.Name = "key_3";
            this.key_3.Size = new System.Drawing.Size(187, 104);
            this.key_3.TabIndex = 0;
            this.key_3.Text = "3";
            this.key_3.UseVisualStyleBackColor = true;
            this.key_3.Click += new System.EventHandler(this.key_3_Click);
            // 
            // key_4
            // 
            this.key_4.Location = new System.Drawing.Point(63, 504);
            this.key_4.Name = "key_4";
            this.key_4.Size = new System.Drawing.Size(187, 104);
            this.key_4.TabIndex = 0;
            this.key_4.Text = "4";
            this.key_4.UseVisualStyleBackColor = true;
            this.key_4.Click += new System.EventHandler(this.key_4_Click);
            // 
            // key_5
            // 
            this.key_5.Location = new System.Drawing.Point(300, 504);
            this.key_5.Name = "key_5";
            this.key_5.Size = new System.Drawing.Size(187, 104);
            this.key_5.TabIndex = 0;
            this.key_5.Text = "5";
            this.key_5.UseVisualStyleBackColor = true;
            this.key_5.Click += new System.EventHandler(this.key_5_Click);
            // 
            // key_6
            // 
            this.key_6.Location = new System.Drawing.Point(539, 504);
            this.key_6.Name = "key_6";
            this.key_6.Size = new System.Drawing.Size(187, 104);
            this.key_6.TabIndex = 0;
            this.key_6.Text = "6";
            this.key_6.UseVisualStyleBackColor = true;
            this.key_6.Click += new System.EventHandler(this.key_6_Click);
            // 
            // key_7
            // 
            this.key_7.Location = new System.Drawing.Point(63, 345);
            this.key_7.Name = "key_7";
            this.key_7.Size = new System.Drawing.Size(187, 104);
            this.key_7.TabIndex = 0;
            this.key_7.Text = "7";
            this.key_7.UseVisualStyleBackColor = true;
            this.key_7.Click += new System.EventHandler(this.key_7_Click);
            // 
            // key_8
            // 
            this.key_8.Location = new System.Drawing.Point(300, 345);
            this.key_8.Name = "key_8";
            this.key_8.Size = new System.Drawing.Size(187, 104);
            this.key_8.TabIndex = 0;
            this.key_8.Text = "8";
            this.key_8.UseVisualStyleBackColor = true;
            this.key_8.Click += new System.EventHandler(this.key_8_Click);
            // 
            // key_9
            // 
            this.key_9.Location = new System.Drawing.Point(539, 345);
            this.key_9.Name = "key_9";
            this.key_9.Size = new System.Drawing.Size(187, 104);
            this.key_9.TabIndex = 0;
            this.key_9.Text = "9";
            this.key_9.UseVisualStyleBackColor = true;
            this.key_9.Click += new System.EventHandler(this.key_9_Click);
            // 
            // key_decimal
            // 
            this.key_decimal.Location = new System.Drawing.Point(63, 821);
            this.key_decimal.Name = "key_decimal";
            this.key_decimal.Size = new System.Drawing.Size(187, 104);
            this.key_decimal.TabIndex = 0;
            this.key_decimal.Text = ".";
            this.key_decimal.UseVisualStyleBackColor = true;
            this.key_decimal.Click += new System.EventHandler(this.key_decimal_Click);
            // 
            // key_0
            // 
            this.key_0.Location = new System.Drawing.Point(300, 821);
            this.key_0.Name = "key_0";
            this.key_0.Size = new System.Drawing.Size(187, 104);
            this.key_0.TabIndex = 0;
            this.key_0.Text = "0";
            this.key_0.UseVisualStyleBackColor = true;
            this.key_0.Click += new System.EventHandler(this.key_0_Click);
            // 
            // key_equal
            // 
            this.key_equal.Location = new System.Drawing.Point(539, 821);
            this.key_equal.Name = "key_equal";
            this.key_equal.Size = new System.Drawing.Size(187, 104);
            this.key_equal.TabIndex = 0;
            this.key_equal.Text = "=";
            this.key_equal.UseVisualStyleBackColor = true;
            this.key_equal.Click += new System.EventHandler(this.key_equal_Click);
            // 
            // key_divide
            // 
            this.key_divide.Location = new System.Drawing.Point(783, 821);
            this.key_divide.Name = "key_divide";
            this.key_divide.Size = new System.Drawing.Size(187, 104);
            this.key_divide.TabIndex = 0;
            this.key_divide.Text = "/";
            this.key_divide.UseVisualStyleBackColor = true;
            this.key_divide.Click += new System.EventHandler(this.key_divide_Click);
            // 
            // key_multiply
            // 
            this.key_multiply.Location = new System.Drawing.Point(783, 669);
            this.key_multiply.Name = "key_multiply";
            this.key_multiply.Size = new System.Drawing.Size(187, 104);
            this.key_multiply.TabIndex = 0;
            this.key_multiply.Text = "*";
            this.key_multiply.UseVisualStyleBackColor = true;
            this.key_multiply.Click += new System.EventHandler(this.key_multiply_Click);
            // 
            // key_minus
            // 
            this.key_minus.Location = new System.Drawing.Point(783, 504);
            this.key_minus.Name = "key_minus";
            this.key_minus.Size = new System.Drawing.Size(187, 104);
            this.key_minus.TabIndex = 0;
            this.key_minus.Text = "-";
            this.key_minus.UseVisualStyleBackColor = true;
            this.key_minus.Click += new System.EventHandler(this.key_minus_Click);
            // 
            // key_plus
            // 
            this.key_plus.Location = new System.Drawing.Point(783, 345);
            this.key_plus.Name = "key_plus";
            this.key_plus.Size = new System.Drawing.Size(187, 104);
            this.key_plus.TabIndex = 0;
            this.key_plus.Text = "+";
            this.key_plus.UseVisualStyleBackColor = true;
            this.key_plus.Click += new System.EventHandler(this.key_plus_Click);
            // 
            // key_C
            // 
            this.key_C.Location = new System.Drawing.Point(539, 178);
            this.key_C.Name = "key_C";
            this.key_C.Size = new System.Drawing.Size(431, 104);
            this.key_C.TabIndex = 0;
            this.key_C.Text = "<--";
            this.key_C.UseVisualStyleBackColor = true;
            this.key_C.Click += new System.EventHandler(this.key_C_Click);
            // 
            // key_CE
            // 
            this.key_CE.Location = new System.Drawing.Point(63, 178);
            this.key_CE.Name = "key_CE";
            this.key_CE.Size = new System.Drawing.Size(424, 104);
            this.key_CE.TabIndex = 0;
            this.key_CE.Text = "CE";
            this.key_CE.UseVisualStyleBackColor = true;
            this.key_CE.Click += new System.EventHandler(this.key_CE_Click);
            // 
            // display_box
            // 
            this.display_box.Location = new System.Drawing.Point(63, 60);
            this.display_box.Name = "display_box";
            this.display_box.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.display_box.Size = new System.Drawing.Size(907, 47);
            this.display_box.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(17F, 41F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1042, 988);
            this.Controls.Add(this.display_box);
            this.Controls.Add(this.key_CE);
            this.Controls.Add(this.key_C);
            this.Controls.Add(this.key_plus);
            this.Controls.Add(this.key_minus);
            this.Controls.Add(this.key_multiply);
            this.Controls.Add(this.key_divide);
            this.Controls.Add(this.key_equal);
            this.Controls.Add(this.key_0);
            this.Controls.Add(this.key_decimal);
            this.Controls.Add(this.key_9);
            this.Controls.Add(this.key_8);
            this.Controls.Add(this.key_7);
            this.Controls.Add(this.key_6);
            this.Controls.Add(this.key_5);
            this.Controls.Add(this.key_4);
            this.Controls.Add(this.key_3);
            this.Controls.Add(this.key_2);
            this.Controls.Add(this.key_1);
            this.Name = "Form1";
            this.Text = "Calc_CS";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button key_1;
        private System.Windows.Forms.Button key_2;
        private System.Windows.Forms.Button key_3;
        private System.Windows.Forms.Button key_4;
        private System.Windows.Forms.Button key_5;
        private System.Windows.Forms.Button key_6;
        private System.Windows.Forms.Button key_7;
        private System.Windows.Forms.Button key_8;
        private System.Windows.Forms.Button key_9;
        private System.Windows.Forms.Button key_decimal;
        private System.Windows.Forms.Button key_0;
        private System.Windows.Forms.Button key_equal;
        private System.Windows.Forms.Button key_divide;
        private System.Windows.Forms.Button key_multiply;
        private System.Windows.Forms.Button key_minus;
        private System.Windows.Forms.Button key_plus;
        private System.Windows.Forms.Button key_C;
        private System.Windows.Forms.Button key_CE;
        private System.Windows.Forms.TextBox display_box;
    }
}

